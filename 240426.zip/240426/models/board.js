const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class Board extends Model {
    static init() {
      return super.init(
        {
          title: {
            type: DataTypes.STRING(30),
          },
          content: {
            type: DataTypes.STRING(5000),
          },
        },
        {
          sequelize,

          modelName: "Board",
          tableName: "board",
          paranoid: true,
          underscored: true,
        }
      );
    }
    static associate(db) {
      db.Board.belongsTo(db.User, {
        foreignKey: "userId",
        targetKey: "id",
      });
      db.Board.belongsTo(db.Category, {
        foreignKey: "categoryId",
        targetKey: "id",
      });
      db.Board.hasMany(db.Recomment, {
        foreignKey: "boardId",
        sourceKey: "id",
      });
    }
  }
  return Board.init();
};

const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class Category extends Model {
    static init() {
      return super.init(
        {
          href: {
            type: DataTypes.STRING(50),
            allowNull: false,
          },
          name: {
            type: DataTypes.STRING(30),
            allowNull: false,
          },
          default: {
            type: DataTypes.STRING(10),
            defaultValue: "false",
          },
        },
        {
          sequelize,
          modelName: "Category",
          tableName: "category",
          paranoid: false,
          underscored: true,
        }
      );
    }
    static associate(db) {
      db.Category.hasMany(db.Board, {
        foreignKey: "categoryId",
        sourceKey: "id",
      });
    }
  }
  return Category.init();
};

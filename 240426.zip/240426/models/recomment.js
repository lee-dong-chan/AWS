const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class Recomment extends Model {
    static init() {
      return super.init(
        {
          recomment: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
            defaultValue: null,
          },
        },
        {
          sequelize,

          modelName: "Recomment",
          tableName: "recomment",
          paranoid: false,
          underscored: true,
        }
      );
    }
    static assciate(db) {
      db.Recomment.belongsTo(db.User, {
        foreignKey: "userId",
        targetKey: "id",
      });
      db.Recomment.belongsTo(db.Board, {
        foreignKey: "boardId",
        targetKey: "id",
      });
    }
  }
  return Recomment.init();
};

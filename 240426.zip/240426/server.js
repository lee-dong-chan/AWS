const express = require("express");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");

require("dotenv").config();

const router = require("./router");
const { sequelize, Category } = require("./models");

const app = express();
app.set("port", process.env.PORT || 3000);

app.use(morgan("dev"));
app.use(cookieParser("cookie_secret"));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.set("view engine", "ejs");
app.set("views", "public");

app.use(express.static("public"));
app.use(router);

sequelize
  .sync({ force: true })
  .then(() => {
    const category = [
      { href: "/free", name: "자유", default: false },
      { href: "/humor", name: "유머", default: false },
      { href: "/qna", name: "질문", default: false },
      { href: "/videos", name: "영상", default: false },
      { href: "/issues", name: "사건 사고", default: false },
      { href: "/match-history", name: "전적 인증", default: false },
      { href: "/fan-art", name: "팬 아트", default: false },
    ];

    for (const { href, name } of category) {
      Category.create({ href, name });
    }
    app.listen(app.get("port"), () => {
      console.log(app.get("port"), "server open");
    });
  })
  .catch((err) => console.error(err));

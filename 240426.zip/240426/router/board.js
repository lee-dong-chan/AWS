const router = require("express").Router();
const {
  sequelize,
  Board,
  User,
  Sequelize,
  Category,
  Recomment,
} = require("../models");

const header = {
  topList: [
    {
      img: "talk",
      name: "톡피지지",
      class: "main",
    },
    {
      img: "lol",
      name: "리그오브레전드",
    },
    {
      img: "dskapp",
      name: "데스크톱",
    },
    {
      img: "tft",
      name: "전략적 팀 전투",
    },
    {
      img: "val",
      name: "발로란트",
    },
    {
      img: "pubg",
      name: "배틀그라운드",
    },
    {
      img: "pal",
      name: "팰월드",
    },
    {
      img: "overwatch",
      name: "오버워치2",
    },
    {
      img: "gigs",
      name: "Gigs",
    },
    {
      img: "duo",
      name: "Duo",
    },
    {
      img: "esports",
      name: "이스포츠",
    },
  ],
  subList: [
    { name: "리그오브레전드" },
    { name: "유저 찾기" },
    { name: "양성소" },
    { name: "잡담소" },
    { name: "배틀그라운드" },
    { name: "오버워치" },
  ],
};

Category.findAll({
  attributes: ["href", "name"],
});

router.get("/write", (req, res) => {
  res.render("write");
});

router.get("/", async (req, res) => {
  try {
    const category = await Category.findAll({
      attributes: ["href", "name"],
    });
    const list = await Board.findAll({
      attributes: ["title", "createdAt", "id"],
      include: [
        {
          model: User,
          attributes: ["nick"],
        },
        {
          model: Category,
          attributes: ["href", "name"],
        },
      ],
      raw: true,
    });

    const body = {
      menu: { category },
      top: { category },
      list: { list },
      item: undefined,
    };
    const temp = category.find((item) => item.default);
    if (temp) temp.default = false;
    res.render("index", {
      title: "전체 게시판",
      header,
      body,
    });
  } catch (err) {
    console.error(err);
  }
});

router.get("/:cate/:id", async (req, res) => {
  console.log("???");
  try {
    const category = await Category.findAll({
      attributes: ["href", "name"],
    });

    const list = await Board.findOne({
      attributes: [
        "title",
        "createdAt",
        "id",
        "content",
        [sequelize.fn("count", "id"), "like"],
      ],
      include: [
        {
          model: User,
          attributes: ["nick"],
        },
        {
          model: Category,
          attributes: ["href", "name"],
        },
        {
          model: Recomment,
          attributes: [],
          // where: { recomment: 1 },
        },
      ],
      where: {
        id: req.params.id,
      },
      raw: true,
    });
    console.log(list);
    const reco = await Recomment.findAll({
      attributes: ["recomment", [sequelize.fn("count", "id"), "like"]],
      where: { recomment: 1, boardId: req.params.id },
      raw: true,
    });

    console.log(reco);
    const item = list[req.params.id - 1];
    const body = {
      menu: { category },
      top: undefined,
      list: undefined,
      item,
      reco,
    };
    console.log(item);
    const temp = category.find((item) => item.default);
    if (temp) temp.default = false;
    const cateItem = category.find(
      (item) => item.href == "/" + req.params.cate
    );
    cateItem.default = true;
    res.render("index", {
      title: cateItem.name + "게시판",
      header,
      body,
    });
    console.log(item);
  } catch (err) {
    console.error(err);
  }
});

router.get("/:cate", async (req, res) => {
  console.log("???111");

  try {
    const category = await Category.findAll({
      attributes: ["href", "name", "default"],
    });
    const list = await Board.findAll({
      attributes: ["title", "createdAt", "id"],
      include: [
        {
          model: User,
          attributes: ["nick"],
        },
        {
          model: Category,
          attributes: ["href", "name"],
          where: { href: "/" + req.params.cate },
        },
      ],
      raw: true,
    });

    const body = {
      menu: { category },
      top: { category },
      list: { list },
      item: undefined,
    };
    const temp = category.find((item) => item.default);
    if (temp) temp.default = false;
    const cateItem = category.find(
      (item) => item.href == "/" + req.params.cate
    );
    cateItem.default = true;
    res.render("index", {
      title: cateItem.name + "게시판",
      header,
      body,
    });
  } catch (err) {
    console.error(err);
  }
});

router.post("/:cate/:id/recomment/:like", async (req, res) => {
  console.log(req.params.name);
  try {
    const list = Recomment.create({
      recomment: req.params.like,
      boardId: req.params.id,
      userId: req.cookies.userId,
    });

    // const item = list[req.params.id - 1];
    // item.recomment += +req.params.like;
    // console.log(item);
    res.redirect(`/${req.params.cate}/${req.params.id}`);
  } catch (err) {
    console.error(err);
  }
});

router.post("/write", (req, res) => {
  Board.create({
    ...req.body,
    userId: req.cookies.userId,
    categoryId: "1",
    default: false,
  });

  res.redirect("/");
});

module.exports = router;

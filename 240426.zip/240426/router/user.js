const router = require("express").Router();
const { User, sequelize } = require("../models");
router.get("/login", (req, res) => {
  res.render("login");
});

router.get("/regist", (req, res) => {
  res.render("regist");
});

router.post("/regist", async (req, res) => {
  console.log(req.body);
  try {
    await sequelize.transaction(async (transaction) => {
      await User.create(req.body, { transaction });
    });
    res.redirect("/user/login");
  } catch (err) {
    console.error(err);
  }
});

router.post("/login", async (req, res) => {
  console.log(req.body);
  const user = await User.findOne({
    where: req.body,
    raw: true,
  });
  console.log(user);
  if (user) {
    res.cookie("user", user.nick);
    res.cookie("userId", user.id);
  }

  res.redirect("/");
});

router.post("/logout", (req, res) => {
  res.cookie("user", null, { maxAge: 0 });
  res.cookie("userId", null, { maxAge: 0 });
  res.redirect("/");
});

module.exports = router;
